package com.hanu.ims.exception;

public class InitializationException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public InitializationException() {
        super("InitializationException");
    }
}
