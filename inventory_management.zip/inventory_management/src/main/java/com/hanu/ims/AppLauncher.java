package com.hanu.ims;

import javafx.application.Application;
import javafx.stage.Stage;

import java.lang.reflect.InvocationTargetException;

/**
 * Created as a separate class to be able to run after Maven JAR Build
 */
public class AppLauncher extends Application {
    public static void main(String[] args) throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
     new App().useStartup(Startup.class).configureSelf().launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
    }
}
