package com.hanu.ims.model.domain;

public enum Role {
    Admin, InventoryManager, Salesperson
}
